package com.paul;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;

public class MainMenu extends javax.swing.JFrame {

	// Создание главного меню

	private javax.swing.JButton phoneMenu;
	private javax.swing.JButton button;
	private javax.swing.JLabel label;
	private javax.swing.JPanel panel;

	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {

			public void run() {
				new MainMenu().setVisible(true);
			}
		});
	}

	public MainMenu() {
		initComponents();
		center();
	}

	private void initComponents() {

		panel = new javax.swing.JPanel();
		phoneMenu = new javax.swing.JButton();
		button = new javax.swing.JButton();
		label = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Телефонный Книжник");
		setBackground(new java.awt.Color(131, 114, 53));
		setUndecorated(true);

		panel.setBorder(new javax.swing.border.SoftBevelBorder(
				javax.swing.border.BevelBorder.RAISED));

		phoneMenu.setText("Телефонная книга ");
		phoneMenu.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				PhoneMenuActionPerformed(evt);
			}
		});

		button.setText("Выход ");
		button.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				panel);
		panel.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addGap(56, 56, 56)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																button,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																265,
																Short.MAX_VALUE)
														.addComponent(
																phoneMenu,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																265,
																Short.MAX_VALUE))
										.addGap(52, 52, 52)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout
						.createSequentialGroup()
						.addGap(33, 33, 33)
						.addComponent(phoneMenu,
								javax.swing.GroupLayout.PREFERRED_SIZE, 54,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(18, 18, 18)
						.addGap(18, 18, 18)
						.addComponent(button,
								javax.swing.GroupLayout.PREFERRED_SIZE, 56,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(22, 22, 22)));

		label.setFont(new java.awt.Font("Tahoma", 1, 18));
		label.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		label.setText("Записник");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(
														layout.createSequentialGroup()
																.addGap(126,
																		126,
																		126)
																.addComponent(
																		label,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		138,
																		javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(
														layout.createSequentialGroup()
																.addGap(24, 24,
																		24)
																.addComponent(
																		panel,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(27, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(label,
								javax.swing.GroupLayout.DEFAULT_SIZE, 29,
								Short.MAX_VALUE)
						.addGap(29, 29, 29)
						.addComponent(panel,
								javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap()));

		pack();
	}

	private void PhoneMenuActionPerformed(java.awt.event.ActionEvent evt) {

		setVisible(false);
		new PhoneBook().show();
		new PhoneBook();

	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			if (JOptionPane.showConfirmDialog(null, "Ну действительно выйти?",
					"Внимание-внимание!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
				System.exit(0);
		} catch (Exception e) {
		}
	}

	private void center() {
		Dimension scr = Toolkit.getDefaultToolkit().getScreenSize();
		int nX = (int) (scr.getWidth() - getWidth()) / 2;
		int nY = (int) (scr.getHeight() - getHeight()) / 2;

		setLocation(nX, nY);
	}
}
