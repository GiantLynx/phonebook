package com.paul;
import java.util.ArrayList;


public class ContactList {
	
	private java.util.List<Contact> list = new ArrayList<Contact>();
	private Contact c1, c2, c3, c4, c5, c6;
	
	{
		c1 = new Contact("Zhora", "Ivanov", "555-55-12", "12-96-01", "superzhora01", "", 1);
		c2 = new Contact("Petya", "Johnes", "555-55-13", "12-97-02", "petyabest", "Some description might be of use here", 2);
		c3 = new Contact("Liza", "Ivanova", "555-55-14", "12-98-01", "theliza.70", "", 3);
		c4 = new Contact("Masha", "Sovenko", "665-35-14", "52-18-01", "90.masha", "", 4);
		c5 = new Contact("Elvis", "Presley", "545-55-14", "12-98-01", "grisha763", "", 5);
		c6 = new Contact("Joe", "Cocker", "753-14-14", "12-98-01", "joecocker", "", 6);
		
		list.add(c1);
		list.add(c2);
		list.add(c3);
		list.add(c4);
		list.add(c5);
		list.add(c6);
	}
	
	
	public ContactList(){
	}
	
	public void add(Contact contact){
		list.add(contact);
	}
	
	public Contact findContactbyName(String name){
		
		for(Contact c : list){
			if(c.getName().equals(name)){
				return c;
			}
		}
		return null;
	}
	
	public Contact findContactbyId(String Id){
		
		int id = Integer.parseInt(Id);
		
		for(Contact c : list){
			if(c.getId() == id ){
				return c;
			}
		}
		return null;
	}
	
	public boolean removeContact(String id){
		Contact c = findContactbyId(id);
		if(c==null){
			return false;
		}
		return list.remove(c);
	}
	
	public Contact first(){
		
		for(Contact contact : list){
			if(contact!=null) return contact;
		}
		
		return null;
		
	}
	
	public Contact last(){
		
		Contact c = list.get(list.size()-1);
		
		if(c!=null){
			return c;
		}
		
		
		
		for(int i = list.size(); i>1; i--){
			if(list.get(i)!=null){
				return list.get(i);
			}
		}
		
		return null;
		
	}
	
	public Contact previous(String id){
		
		try{
			int myId = Integer.parseInt(id)-1;
			Contact c;
			
			if(list.size()<myId){
				myId=list.size();
			}
			
			for(;myId>=1; myId--){
				
				
				c = list.get(myId-1);
				
				if(c!=null){
					return c;
				}
				System.out.println("Previous id: " + myId);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public Contact next(String id){
		
		try{
			int myId = Integer.parseInt(id);
			Contact c;
			
			for(; myId<=list.size(); myId++){
				c = list.get(myId);
				if(c!=null){
					return c;
				}
			}
			
		}
		catch(Exception e){
			return null;
		}
		
		return null;
		
	}
	

}
