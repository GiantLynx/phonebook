package com.paul;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JOptionPane;

@SuppressWarnings("serial")
public class PhoneBook extends javax.swing.JFrame {

	private javax.swing.JLabel jLabelLastName;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabelName;
	private javax.swing.JLabel jLabelNum;
	private javax.swing.JLabel jLabelInfo;
	private javax.swing.JLabel jLabelFax;
	private javax.swing.JLabel jLabelSkype;
	private javax.swing.JLabel jLabelId;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JButton jbtPrevious;
	private javax.swing.JButton addButton;
	private javax.swing.JButton backButton;
	private javax.swing.JButton clearButton;
	private javax.swing.JButton deleteButton;
	private javax.swing.JButton exitButton;
	private javax.swing.JButton firstButton;
	private javax.swing.JButton lastButton;
	private javax.swing.JButton nextButton;
	private javax.swing.JButton searchButton;
	private javax.swing.JButton updateButton;
	private javax.swing.JTextArea txtInfo;
	@SuppressWarnings("rawtypes")
	private javax.swing.JTextField txtFax;
	private javax.swing.JTextField txtLastName;
	private javax.swing.JTextField txtSkype;
	private javax.swing.JTextField txtName;
	private javax.swing.JTextField txtNum;
	private javax.swing.JTextField txtId;

	public static PhoneBook phoneBook = new PhoneBook();
	public static ContactList contactList = new ContactList();

	
	{
		initComponents();
		center();
	}

	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {

			public void run() {
				new PhoneBook().setVisible(true);
			}
		});
	}

	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jLabelNum = new javax.swing.JLabel();
		jLabelLastName = new javax.swing.JLabel();
		jLabelName = new javax.swing.JLabel();
		jLabelInfo = new javax.swing.JLabel();
		jLabelFax = new javax.swing.JLabel();
		jLabelSkype = new javax.swing.JLabel();
		jLabelId = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		txtId = new javax.swing.JTextField();
		txtName = new javax.swing.JTextField();
		txtLastName = new javax.swing.JTextField();
		jScrollPane1 = new javax.swing.JScrollPane();
		txtInfo = new javax.swing.JTextArea();
		txtFax = new javax.swing.JTextField();
		txtSkype = new javax.swing.JTextField();
		txtNum = new javax.swing.JTextField();
		txtId = new javax.swing.JTextField();
		jLabel10 = new javax.swing.JLabel();
		addButton = new javax.swing.JButton();
		deleteButton = new javax.swing.JButton();
		searchButton = new javax.swing.JButton();
		exitButton = new javax.swing.JButton();
		clearButton = new javax.swing.JButton();
		backButton = new javax.swing.JButton();
		updateButton = new javax.swing.JButton();
		firstButton = new javax.swing.JButton();
		jbtPrevious = new javax.swing.JButton();
		nextButton = new javax.swing.JButton();
		lastButton = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setUndecorated(true);

		jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(
				javax.swing.border.BevelBorder.RAISED));

		jLabelNum.setText("Тел.:");

		jLabelLastName.setText("Фамилия:");

		jLabelName.setText("Имя:");

		jLabelInfo.setText("Инфа:");

		jLabelFax.setText("Факс:");

		jLabelSkype.setText("Скайп:");

		jLabelId.setText("id: ");

		jLabel9.setText("  ");

		clearText();

		txtInfo.setColumns(20);
		txtInfo.setRows(5);
		jScrollPane1.setViewportView(txtInfo);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addGroup(
																												jPanel1Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addGroup(
																																jPanel1Layout
																																		.createParallelGroup(
																																				javax.swing.GroupLayout.Alignment.LEADING)
																																		.addGroup(
																																				jPanel1Layout
																																						.createSequentialGroup()
																																						.addGroup(
																																								jPanel1Layout
																																										.createParallelGroup(
																																												javax.swing.GroupLayout.Alignment.LEADING)
																																										.addComponent(
																																												jLabelLastName)
																																										.addComponent(
																																												jLabelName,
																																												javax.swing.GroupLayout.Alignment.TRAILING,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												javax.swing.GroupLayout.DEFAULT_SIZE,
																																												Short.MAX_VALUE))
																																						.addGap(18,
																																								18,
																																								18))
																																		.addGroup(
																																				jPanel1Layout
																																						.createSequentialGroup()
																																						.addComponent(
																																								jLabelNum,
																																								javax.swing.GroupLayout.PREFERRED_SIZE,
																																								51,
																																								javax.swing.GroupLayout.PREFERRED_SIZE)
																																						.addGap(47,
																																								47,
																																								47)))
																														.addGroup(
																																jPanel1Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabelInfo,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				59,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addGap(39,
																																				39,
																																				39)))
																										.addGroup(
																												jPanel1Layout
																														.createSequentialGroup()
																														.addComponent(
																																jLabelFax,
																																javax.swing.GroupLayout.PREFERRED_SIZE,
																																46,
																																javax.swing.GroupLayout.PREFERRED_SIZE)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabelSkype)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
																		.addGroup(
																				jPanel1Layout
																						.createSequentialGroup()
																						.addComponent(
																								jLabelId,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								85,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel9,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(37,
																				37,
																				37)))
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addComponent(txtNum)
														.addComponent(txtName)
														.addComponent(
																txtLastName)
														.addComponent(txtSkype)
														.addComponent(
																txtFax,
																0,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addComponent(
																jScrollPane1,
																0, 0,
																Short.MAX_VALUE)
														.addComponent(
																txtId,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																202,
																Short.MAX_VALUE)
														.addComponent(
																txtNum,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																207,
																Short.MAX_VALUE))
										.addGap(88, 88, 88)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGap(27, 27, 27)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelLastName)
														.addComponent(
																txtLastName,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(16, 16, 16)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jLabelName)
														.addComponent(
																txtName,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(16, 16, 16)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabelNum)
														.addComponent(
																txtNum,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(24,
																				24,
																				24)
																		.addComponent(
																				jLabelInfo))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jScrollPane1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				63,
																				javax.swing.GroupLayout.PREFERRED_SIZE)))
										.addGap(25, 25, 25)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabelFax)
														.addComponent(
																txtFax,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jLabelSkype)
														.addComponent(
																txtSkype,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabelId))
										.addComponent(
												txtId,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE))
						.addGap(28, 28, 28)
						.addGroup(
								jPanel1Layout
										.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
										.addComponent(jLabel9)
										.addGap(73, 73, 73)));

		jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12));
		jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel10.setText("Телефонная Книжка ");
		jLabel10.setBorder(new javax.swing.border.SoftBevelBorder(
				javax.swing.border.BevelBorder.RAISED));
		jLabel10.setOpaque(true);

		addButton.setBackground(new java.awt.Color(102, 255, 102));
		addButton.setText("Добавить");

		addButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addActionPerformed(evt);
			}
		});

		deleteButton.setBackground(new java.awt.Color(102, 255, 102));
		deleteButton.setText("Удалить");

		deleteButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				deleteActionPerformed(evt);
			}
		});

		searchButton.setBackground(new java.awt.Color(102, 255, 102));
		searchButton.setText("Поиск");

		searchButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				searchActionPerformed(evt);
			}
		});

		exitButton.setBackground(new java.awt.Color(102, 255, 102));
		exitButton.setText("Выход");

		exitButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitActionPerformed(evt);
			}
		});

		clearButton.setBackground(new java.awt.Color(102, 255, 102));
		clearButton.setText("Удалить");

		clearButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				clearActionPerformed(evt);
			}
		});

		backButton.setBackground(new java.awt.Color(102, 255, 102));
		backButton.setText("Назад");

		backButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				backActionPerformed(evt);
			}
		});

		updateButton.setText("Обновить");

		updateButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				updateActionPerformed(evt);
			}
		});

		firstButton.setText("Первый");
		firstButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				firstRegistryActionPerformed(evt);
			}
		});

		jbtPrevious.setText("Предыдущий");
		jbtPrevious.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				previousRegistryActionPerformed(evt);
			}
		});

		nextButton.setText("Следующий");
		nextButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				nextRegistryActionPerformed(evt);
			}
		});

		lastButton.setText("Последний");
		lastButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				lastRegistryActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addGap(109, 109, 109)
								.addComponent(jLabel10,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										300,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap(142, Short.MAX_VALUE))
				.addGroup(
						layout.createSequentialGroup()
								.addGap(20, 20, 20)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(
														layout.createSequentialGroup()
																.addComponent(
																		firstButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		100,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		jbtPrevious)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		nextButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		120,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																.addComponent(
																		lastButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		120,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addContainerGap())
												.addGroup(
														layout.createSequentialGroup()
																.addComponent(
																		jPanel1,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(
																		layout.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						backButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						100,
																						Short.MAX_VALUE)
																				.addComponent(
																						exitButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						100,
																						Short.MAX_VALUE)
																				.addComponent(
																						clearButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						100,
																						Short.MAX_VALUE)
																				.addComponent(
																						searchButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						100,
																						Short.MAX_VALUE)
																				.addComponent(
																						deleteButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						100,
																						Short.MAX_VALUE)
																				.addComponent(
																						addButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						100,
																						Short.MAX_VALUE)
																				.addComponent(
																						updateButton,
																						javax.swing.GroupLayout.Alignment.TRAILING,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						81,
																						Short.MAX_VALUE))
																.addContainerGap(
																		26,
																		javax.swing.GroupLayout.PREFERRED_SIZE)))));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(
														layout.createSequentialGroup()
																.addGap(28, 28,
																		28)
																.addComponent(
																		jLabel10,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		25,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addGap(18, 18,
																		18)
																.addComponent(
																		jPanel1,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		500,
																		javax.swing.GroupLayout.PREFERRED_SIZE))
												.addGroup(
														layout.createSequentialGroup()
																.addGap(122,
																		122,
																		122)
																.addComponent(
																		addButton)
																.addGap(18, 18,
																		18)
																.addComponent(
																		deleteButton)
																.addGap(18, 18,
																		18)
																.addComponent(
																		searchButton)
																.addGap(18, 18,
																		18)
																.addComponent(
																		updateButton)
																.addGap(18, 18,
																		18)
																.addComponent(
																		clearButton)
																.addGap(18, 18,
																		18)
																.addComponent(
																		exitButton)
																.addGap(18, 18,
																		18)
																.addComponent(
																		backButton)))
								.addGap(18, 18, 18)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(firstButton)
												.addComponent(jbtPrevious)
												.addComponent(nextButton)
												.addComponent(lastButton))
								.addGap(13, 13, 13)));

		pack();
	}

	private Contact createNewContact(String name, String lastName,
			String phone, String fax, String skype, String info, String id) {
		return new Contact(name, lastName, phone, fax, skype, info,
				Integer.parseInt(id));
	}

	private void addActionPerformed(java.awt.event.ActionEvent evt) {

		Contact c = contactList.findContactbyId(txtId.getText());
		Contact contact = createNewContact(txtName.getText(),
				txtLastName.getText(), txtNum.getText(), txtFax.getText(),
				txtSkype.getText(), txtInfo.getText(), txtId.getText());

		String msg = "Вы успешно добавили запись в записную книжку!";

		if (c != null) {
			contactList.removeContact(txtId.getText());
			msg = "Вы заменили запись в записной книжке!";
		}
		contactList.add(contact);
		JOptionPane.showMessageDialog(null, msg, "Сообщение",
				JOptionPane.INFORMATION_MESSAGE);
	}

	private void deleteActionPerformed(java.awt.event.ActionEvent evt) {

		Contact c = contactList.findContactbyId(txtId.getText());
		setText(c);

		if (contactList.removeContact(txtId.getText())) {
			JOptionPane.showMessageDialog(null, "Запись:  " + txtName.getText()
					+ " была успешно удалена", "Сообщение",
					JOptionPane.INFORMATION_MESSAGE);
			clearText();
		} else {
			JOptionPane.showMessageDialog(null, "Запись не была найден!",
					"Сообщение", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	private void searchActionPerformed(java.awt.event.ActionEvent evt) {

		Contact c = contactList.findContactbyId(txtId.getText());
		if (c == null) {
			clearText();
			JOptionPane.showMessageDialog(null, "Запись не была найден!",
					"Сообщение", JOptionPane.INFORMATION_MESSAGE);
		} else {
			setText(c);
		}
	}

	private void exitActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			if (JOptionPane.showConfirmDialog(null,
					"Вы точно хотите вернуться в стартовое меню?",
					"Не, ну серьёзно?", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
				setVisible(false);
			new MainMenu().show();
			MainMenu mainMenu = new MainMenu();
		} catch (Exception e) {
		}
	}

	private void clearActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			clearText();
		} catch (Exception e) {
		}
	}

	@SuppressWarnings("deprecation")
	private void backActionPerformed(java.awt.event.ActionEvent evt) {
		setVisible(false);
		new MainMenu().show();
		MainMenu mainMenu = new MainMenu();
	}

	private void updateActionPerformed(java.awt.event.ActionEvent evt) {

			int choice = JOptionPane.showConfirmDialog(null,
					"Вы точно хотите обновить эту запись?", "Ну серьёзно?",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			if (choice == JOptionPane.YES_OPTION) {
				
				Contact c = contactList.findContactbyId(txtId.getText());
				c.setFax(txtFax.getText());
				c.setId(Integer.parseInt(txtId.getText()));
				c.setInfo(txtInfo.getText());
				c.setLastName(txtLastName.getText());
				c.setName(txtName.getText());
				c.setPhone(txtNum.getText());
				c.setSkype(txtSkype.getText());
				setText(c);
				JOptionPane.showMessageDialog(null, "Запись была успешно обновлена!",
						"Сообщение", JOptionPane.INFORMATION_MESSAGE);
			}
	}

	private void firstRegistryActionPerformed(java.awt.event.ActionEvent evt) {
		Contact c = contactList.first();
		setText(c);
	}

	private void previousRegistryActionPerformed(java.awt.event.ActionEvent evt) {
		
		Contact c = contactList.previous(txtId.getText());
		
		if(c!=null){
			setText(c);
		}
		else{
			JOptionPane.showMessageDialog(null, "Дальше некуда!",
					"Сообщение", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	private void nextRegistryActionPerformed(java.awt.event.ActionEvent evt) {
		
		Contact c = contactList.next(txtId.getText());
		
		if(c!=null){
			setText(c);
		}
		else{
			JOptionPane.showMessageDialog(null, "Конец списка!",
					"Сообщение", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	private void lastRegistryActionPerformed(java.awt.event.ActionEvent evt) {
		Contact c = contactList.last();
		setText(c);
	}


	public void setText(Contact c) {

		txtName.setText(c.getName());
		txtLastName.setText(c.getLastName());
		txtInfo.setText(c.getInfo());
		txtFax.setText(c.getFax());
		txtSkype.setText(c.getSkype());
		txtNum.setText(c.getPhone());
		txtId.setText("" + c.getId());
	}

	public void clearText() {

		txtId.setText("");
		txtName.setText("");
		txtLastName.setText("");
		txtInfo.setText("");
		txtFax.setText("");
		txtSkype.setText("");
		txtNum.setText("");

	}

	private void center() {
		Dimension scr = Toolkit.getDefaultToolkit().getScreenSize();
		int nX = (int) (scr.getWidth() - getWidth()) / 2;
		int nY = (int) (scr.getHeight() - getHeight()) / 2;

		setLocation(nX, nY);
	}

	public void color() {
		addButton.setBackground(Color.LIGHT_GRAY);
		backButton.setBackground(Color.LIGHT_GRAY);
		clearButton.setBackground(Color.LIGHT_GRAY);
		updateButton.setBackground(Color.LIGHT_GRAY);
		deleteButton.setBackground(Color.LIGHT_GRAY);
		exitButton.setBackground(Color.LIGHT_GRAY);
		searchButton.setBackground(Color.LIGHT_GRAY);
	}

}
